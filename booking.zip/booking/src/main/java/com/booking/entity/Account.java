package com.booking.entity;

public class Account {
}
