package com.booking.entity;

import lombok.Builder;
import lombok.Data;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name ="doctor")
@Data
@Builder
public class Doctor  {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private String name;
    private String address;
    private String email;
    private String phone;

    @ManyToMany(mappedBy = "doctorSet")
    Set<Specilaztaion> specilaztaions= new HashSet<>();

    @ManyToMany(mappedBy = "doctorslotSet")
    Set<BookingSlot> bookingSlotset= new HashSet<>();
}
