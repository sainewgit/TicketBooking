package com.booking.entity;

import lombok.Builder;
import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "appoitment")
@Data
@Builder
public class Appoitment {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;


}
