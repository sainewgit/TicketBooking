package com.booking.entity;

import lombok.Builder;
import lombok.Data;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.Set;


@Entity
@Table(name = "bookingslots")
@Data
@Builder
public class BookingSlot {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private String status;
    private String dayOfWeek;
    private LocalDate date;
    private LocalTime openSlotTime;

    @ManyToMany
    @JoinTable(
            name = "doctor_slot",
            joinColumns = @JoinColumn(name = "slot_id"),
            inverseJoinColumns = @JoinColumn(name = "doctor_id"))
    Set<Doctor> doctorslotSet= new HashSet<>();
}
