package com.booking.entity;

import lombok.Builder;
import lombok.Data;

import javax.persistence.*;


//@Data
//@Entity
//@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public abstract class Person {
  //@Id
  //@GeneratedValue(strategy = GenerationType.AUTO)
  private long id;
  private String name;
  private Address address;
  private String email;
  private String phone;
}