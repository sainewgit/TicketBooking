package com.booking.entity;

import lombok.Builder;
import lombok.Data;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "specilazation")
@Data
@Builder
public class Specilaztaion {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "specilazation")
    private String specilazation;

    @ManyToMany
    @JoinTable(
            name = "specdock_like",
            joinColumns = @JoinColumn(name = "doctor_id"),
            inverseJoinColumns = @JoinColumn(name = "spc_id"))
    Set<Doctor> doctorSet= new HashSet<>();
}
