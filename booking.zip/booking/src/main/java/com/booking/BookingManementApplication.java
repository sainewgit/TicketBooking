package com.booking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookingManementApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookingManementApplication.class, args);
	}

}
